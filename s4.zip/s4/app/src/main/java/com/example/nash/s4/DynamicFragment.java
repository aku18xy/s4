package com.example.nash.s4;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.nash.s4.DataBank.Category;
import com.example.nash.s4.DataBank.ConnectData;
import com.example.nash.s4.DataBank.DataUtil;
import com.example.nash.s4.DataBank.Item;
import com.example.nash.s4.DataBank.MasterData;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class DynamicFragment extends Fragment implements View.OnClickListener {

    public static String ARG_PAGE = "arg_page";
    public static String ARG_LOCK = "arg_lock";
    int mPage, mLock;
    int btnStat;
    OnConnectButton CB;
    Button btnConn;
    private static TextView tvConn;
    ViewGroup conLayout;
    ItemAdapter adapter;
    private DataUtil dataUtil;
    private String connectInfo = null;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnConnection:

                switch (btnStat) {
                    case 0:
                        btnConn.setText(R.string.LOCK);
                        btnStat = 1;
                        CB.buttonClick(btnStat);
                        break;
                    case 1:
                        btnConn.setText(R.string.UNLOCK);
                        btnStat = 2;
                        CB.buttonClick(btnStat);
                        break;
                    case 2:
                        btnConn.setText(R.string.LOCK);
                        btnStat = 1;
                        CB.buttonClick(btnStat);
                        break;
                }

                break;
        }
    }

    public interface OnConnectButton {
        void buttonClick(int stat);
    }

    @Override
    public void onAttach(Context context) {
        try {
            CB = (OnConnectButton) context;
        }catch (ClassCastException e) {
            throw new ClassCastException(context.toString());
        }
        super.onAttach(context);
    }

    public static DynamicFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        DynamicFragment fragment = new DynamicFragment();
        fragment.setArguments(args);
        return fragment;
    }


    public DynamicFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_dynamic, container, false);

        RecyclerView recycle = v.findViewById(R.id.recycle);
        conLayout = v.findViewById(R.id.connectionLayout);
        btnConn = v.findViewById(R.id.btnConnection);
        tvConn = v.findViewById(R.id.tvConnection);

//        DataUtil dUwInterface = new DataUtil(this);


        dataUtil = new DataUtil(getActivity());
        MasterData masterData = dataUtil.getMasterData();
        List<Category> categoryList = masterData.getCategories();
        List<Item> itemList = categoryList.get(mPage-1).getItems();

//        List<Item> itemList = new DataUtil(getActivity()).getMasterData().getCategories().get(mPage-1).getItems();
        adapter = new ItemAdapter(itemList);
        recycle.setAdapter(adapter);
        recycle.setHasFixedSize(true);
        recycle.setLayoutManager(new LinearLayoutManager(getActivity()));

        btnStat = 0;
        btnConn.setText(R.string.SCAN);

        if (mPage==1) {
            conLayout.setVisibility(View.VISIBLE);
            btnConn.setOnClickListener(this);
            tvConn.setText(connectInfo);

        }else {
            conLayout.removeAllViews();
        }

        return v;
    }

    public void updateConnectInfo(ConnectData data) {
        this.connectInfo = data.getInfo();
        notify();
//        Log.d("HOHO", info);
    }

    public void onRefresh(int catIndex) {
        if (mPage==catIndex+1) {

            boolean ada = dataUtil.adeKe();
            int itemIndex = dataUtil.getItemIndex();
            Log.d("s3", "adeke=" + String.valueOf(ada));

            List<Item> itemList = dataUtil.getMasterData().getCategories()
                    .get(catIndex).getItems();
            adapter.updateItemAdapter(itemList);
            adapter.notifyDataSetChanged();

            if (ada)
                adapter.notifyItemChanged(itemIndex);
            Log.d("s3", "onRefresh : " + catIndex);
            Log.d("s3", "onRefresh : " + itemIndex);



        }
    }

}
