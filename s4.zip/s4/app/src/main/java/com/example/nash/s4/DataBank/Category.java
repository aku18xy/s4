package com.example.nash.s4.DataBank;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Category {

    private String Name;

    @SerializedName("Item")
    private List<Item> Items;

    public Category(String name) {
        Name = name;
    }

    public Category(String name, List<Item> items) {
        Name = name;
        Items = items;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public List<Item> getItems() {
        return Items;
    }

    public void setItems(List<Item> items) {
        Items = items;
    }
}
