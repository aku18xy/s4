package com.example.nash.s4.DataBank;

import android.support.annotation.Nullable;

public class Item {

    private String Label;

    @Nullable
    private String Value;

    private int ValueType;

    public Item(String label, String value, int valueType) {
        Label = label;
        Value = value;
        ValueType = valueType;
    }

    public String getLabel() {
        return Label;
    }

    public void setLabel(String label) {
        Label = label;
    }

    public CharSequence getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public int getValueType() {
        return ValueType;
    }

    public void setValueType(int valueType) {
        ValueType = valueType;
    }
}
