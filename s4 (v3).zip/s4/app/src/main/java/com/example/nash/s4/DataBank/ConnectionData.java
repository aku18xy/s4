package com.example.nash.s4.DataBank;

public class ConnectionData {

    private String info;

    public ConnectionData(String info) {
        this.info = info;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
