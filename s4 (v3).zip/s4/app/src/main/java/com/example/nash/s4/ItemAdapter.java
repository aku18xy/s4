package com.example.nash.s4;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.example.nash.s4.DataBank.Item;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> items;

    public ItemAdapter() {
    }

    public ItemAdapter(List<Item> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item, parent, false);
        return new ItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, int position) {
        final Item item = items.get(position);
        holder.tv.setText(item.getLabel());
        CharSequence value = item.getValue();
        int type = item.getValueType();
        switch (type) {
            case 1:
                holder.et.setInputType(InputType.TYPE_CLASS_TEXT);
                holder.et.setFocusable(true);
                holder.et.setFocusableInTouchMode(true);
                break;
            case 2:
                holder.et.setInputType(InputType.TYPE_CLASS_NUMBER);
                holder.et.setFocusable(true);
                holder.et.setFocusableInTouchMode(true);
                break;
            case 0:
                holder.et.setEnabled(false);
                holder.et.setKeyListener(null);
                holder.et.setFocusable(false);
                holder.et.setClickable(false);
                break;
        }

        if (value != null)
            holder.et.setText(value);

        // ref : https://stackoverflow.com/questions/10627137/how-can-i-know-when-an-edittext-loses-focus
        if (type!=0) {
            holder.et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        String txt = holder.et.getText().toString();
                        Log.d("tagLine", txt);
                        if (!txt.equals("")) {
                            item.setValue(txt);
                        }
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return items!=null ? items.size() : 0;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        public TextView tv;
        public EditText et;

        public ItemViewHolder(View itemView) {
            super(itemView);

            tv = itemView.findViewById(R.id.tvSingleItem);
            et = itemView.findViewById(R.id.etSingleItem);

        }
    }

    public void updateItemAdapter(List<Item> items) {
        this.items = items;
        Log.d("s3", "updateItemAdapter");
    }
}
