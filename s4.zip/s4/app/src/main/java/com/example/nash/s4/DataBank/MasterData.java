package com.example.nash.s4.DataBank;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MasterData {

    @SerializedName("Category")
    List<Category> Categories;

    public List<Category> getCategories() {
        return Categories;
    }

    public void setCategories(List<Category> categories) {
        Categories = categories;
    }
}
