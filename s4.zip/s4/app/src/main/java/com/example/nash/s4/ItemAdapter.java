package com.example.nash.s4;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.example.nash.s4.DataBank.Item;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> items;

    public ItemAdapter() {
    }

    public ItemAdapter(List<Item> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item, parent, false);
        return new ItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = items.get(position);
        holder.tv.setText(item.getLabel());
        CharSequence value = item.getValue();
        switch (item.getValueType()) {
            case 1:
                holder.et.setInputType(InputType.TYPE_CLASS_TEXT);
                if (value != null)
                    holder.et.setText(value);
                break;
            case 2:
                holder.et.setInputType(InputType.TYPE_CLASS_NUMBER);
                if (value != null)
                    holder.et.setText(value);
                break;
            case 0:
                holder.et.setEnabled(false);
                holder.et.setKeyListener(null);
                holder.et.setFocusable(false);
                holder.et.setClickable(false);
                holder.et.setText(item.getValue());
                break;
        }

    }

    @Override
    public int getItemCount() {
        return items!=null ? items.size() : 0;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        public TextView tv;
        public EditText et;

        public ItemViewHolder(View itemView) {
            super(itemView);

            tv = itemView.findViewById(R.id.tvSingleItem);
            et = itemView.findViewById(R.id.etSingleItem);

        }
    }



    public void updateItemAdapter(List<Item> items) {
        this.items = items;
//        notifyDataSetChanged();
        Log.d("s3", "updateItemAdapter");
    }
}
