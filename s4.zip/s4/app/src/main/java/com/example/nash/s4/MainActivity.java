package com.example.nash.s4;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.nash.s4.DataBank.Category;
import com.example.nash.s4.DataBank.ConnectData;
import com.example.nash.s4.DataBank.DataUtil;
import com.example.nash.s4.DataBank.MasterData;
import com.example.nash.s4.DataBank.NewData;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener, DynamicFragment.OnConnectButton {

    List<Category> categories;
    TabLayout tabLayout;
    ViewPager viewPager;
    TabAdapter tabAdapter;
    AppBarLayout abLayout;
    TextView tvABLayout;
    Fragment frag01;
    DataUtil dataUtil, dUwInterface;
    MasterData masterData, onlineData;
    private Button btnUpdate;
    private EditText etCategory, etLabel, etValue, etValueType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);


        abLayout = findViewById(R.id.appBarLayout);
        tvABLayout = findViewById(R.id.tvABLayout);
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        dataUtil = new DataUtil(getApplicationContext());
        onlineData = new Gson().fromJson(loadJSONFromAsset(), MasterData.class);
        dataUtil.setMasterData(onlineData);
        masterData = dataUtil.getMasterData();
        categories = masterData.getCategories();

        tabAdapter = new TabAdapter(getSupportFragmentManager(), categories);
        viewPager.setAdapter(tabAdapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(this);

        tvABLayout.setText("S4 (S2+S3)");
    }

    // call this method to update data -->
    // dataUtil.updateData(int catIndex, List<Item> itemListDariLuar);

    @Override
    public void buttonClick(int stat) {
        // ni button utk lock connection
        // int stat : default = 0, 1 = scan/unlock, 2 = lock,

        //// Example to update data ////
        NewData newData1 = new Gson().fromJson(loadNewData1(), NewData.class);
        NewData newData2 = new Gson().fromJson(loadNewData2(), NewData.class);

        Log.d("tagLine", String.valueOf(stat));

        switch (stat) {
            case 1:
                dataUtil.updateData(newData1);
                updateFragment();
                break;
            case 2:
                dataUtil.updateData(newData2);
                updateFragment();
                break;
        }

        //////////////////////////////////////////////////////////////////////////////
    }

    // call this function to update fragment ui
    public void updateFragment() {
        int pos = tabLayout.getSelectedTabPosition();
        Fragment fr = tabAdapter.getFragment(pos);
        if (fr != null) {
            ((DynamicFragment)fr).onRefresh(pos);
        }
    }

    // assumed that this is function that return json string from network..
    // supply the string to gson as //// Example to update data //// above..
    public String loadNewData2() {
        String json = null;
        try {
            InputStream is = getApplicationContext().getAssets().
                    open("newData2.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        Log.d("json", "dpt baca");
        return json;
    }

    public String loadNewData1() {
        String json = null;
        try {
            InputStream is = getApplicationContext().getAssets().
                    open("newData1.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        Log.d("json", "dpt baca");
        return json;
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getApplicationContext().getAssets().
                    open("data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        Log.d("json", "dpt baca");
        return json;
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        if (tabLayout.getSelectedTabPosition()!=0)
            updateFragment();
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

}
